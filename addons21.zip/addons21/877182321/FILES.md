* changeFunction: ensure that Anki's methods are changed by the new one
* column: from HTML to configuration, deleting/moving column
* config: allow to access and update config
* htmlAndCss: constants and methods allowing to CSS and HTML to be
  entered in the deckBrowser
* node: compute the values associated with each deck, taking subdecks into
  account
* printing: method to compute the strings shown to the user
* strings: dictionaries associating to each name the column's header
  and description
* Computing the set of values associated with each card
