<h2># Read this</h2>

the setting `when narrow move search bar to extra line` has no effect if 
- your Anki version is 2.1.41 or higher or
- you have a version 
of the add-on [BetterSearch](https://ankiweb.net/shared/info/1052724801) installed that was 
released (updated) after 2020-07-15. You can check the release date of an add-on on the 
ankiweb site. Below the big and bold add-on name there's a small line that has 
e.g. "Updated 2020-07-04".
