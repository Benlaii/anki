This README ensures that a user_files folder is created for the user. 

In this folder is the database, where details onupcoming events are stored.

