**CONFIGURATION** 

The properties  you can modify include:

- `hotkey` and `tooltip` of each action
- order of actions (by shifting the `{}`-enclosed button definitions around)
- available actions (by deleting any of the `{}`-enclosed button definitions)

Your changes will be applied once you restart your editor window (if running). Please do not change the '`name`' property, as this is used to assign the corresponding button to the function it calls.