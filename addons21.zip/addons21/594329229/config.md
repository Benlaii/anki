**Hierarchical Tags 2** supports the following config values:

<div style="color: #ff8080; font-weight: bold;">Please note that you will have to restart Anki for these options to apply</div>

**Separator** [string]: Separator text between different hierarchical tag levels. Default: `::`

---

Hierarchical Tags was originally created by [Patrice Neff](https://patrice.ch/).

This updated version is maintained by [Glutanimate](https://glutanimate.com).
