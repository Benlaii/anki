Created with <span style="color: #ff3d2e; font-weight: bold;">❤️</span> by [Glutanimate](https://glutanimate.com). If you enjoy this add-on, please consider supporting my work by **[pledging your support on Patreon](https://www.patreon.com/bePatron?u=7522179)** or by **[buying me a coffee](https://ko-fi.com/X8X0L4YV)**. Thanks!

---

<span style="color: #249191; font-weight: bold;">Highlight Search Results in the Browser</span> supports the following config values:

**highlight_by_default** (true/false): Turn search highlights on by default. Default: `true`.

**hotkey_toggle_highlights** (hotkey string): Hotkey to toggle highlights on/off. Default: `Ctrl+T, H`.

**hotkey_select_next_matching_card** (hotkey string): Hotkey to select next matching card. Default: `Shift+Return`.

**hotkey_select_all_matching_cards** (hotkey string): Hotkey to select all matching cards. Default: `Ctrl+Shift+Return`.

---

[Changelog](https://github.com/glutanimate/highlight-search-results/blob/master/CHANGELOG.md)

[AnkiWeb page](https://ankiweb.net/shared/info/225180905)

[Feedback/Suggestions](https://github.com/glutanimate/highlight-search-results/issues)
