filename                        origin

align-bottom.png                http://tango.freedesktop.org/static/cvs/tango-art-libre/22x22/actions/align-vertical-bottom.png
align-bottom.svg                http://tango.freedesktop.org/static/cvs/tango-art-libre/22x22/actions/align-vertical-bottom.svg
align-center.png                http://tango.freedesktop.org/static/cvs/tango-art-libre/22x22/actions/align-horizontal-center.png
align-center.svg                http://tango.freedesktop.org/static/cvs/tango-art-libre/22x22/actions/align-horizontal-center.svg
align-left.png                  http://tango.freedesktop.org/static/cvs/tango-art-libre/22x22/actions/align-horizontal-left.png
align-left.svg                  http://tango.freedesktop.org/static/cvs/tango-art-libre/22x22/actions/align-horizontal-left.svg
align-middle.png                http://tango.freedesktop.org/static/cvs/tango-art-libre/22x22/actions/align-vertical-center.png
align-middle.svg                http://tango.freedesktop.org/static/cvs/tango-art-libre/22x22/actions/align-vertical-center.svg
align-right.png                 http://tango.freedesktop.org/static/cvs/tango-art-libre/22x22/actions/align-horizontal-right.png
align-right.svg                 http://tango.freedesktop.org/static/cvs/tango-art-libre/22x22/actions/align-horizontal-right.svg
align-top.png                   http://tango.freedesktop.org/static/cvs/tango-art-libre/22x22/actions/align-vertical-top.png
align-top.svg                   http://tango.freedesktop.org/static/cvs/tango-art-libre/22x22/actions/align-vertical-top.svg
bold.png
cancel.png
circle.png
clear.png
clone.png
copy.png
cut.png
delete.png
document-properties.png
dropdown.gif
ellipse.png
eye.png
flyouth.png
flyup.gif
freehand-circle.png
freehand-square.png
go-down.png
go-up.png
image.png
italic.png
line.png
logo.png
logo.svg
move_bottom.png
move_top.png
none.png
open.png
paste.png
path.png
polygon.png                     http://tango.freedesktop.org/static/cvs/tango-art-libre/22x22/tools/draw-polygon.png
polygon.svg                     http://tango.freedesktop.org/static/cvs/tango-art-libre/22x22/tools/draw-polygon.svg
rect.png
redo.png
rotate.png
save.png
select.png
sep.png
shape_group.png
shape_ungroup.png
source.png
square.png
text.png                        http://tango.freedesktop.org/static/cvs/tango-art-libre/22x22/tools/draw-text.png
text.svg                        http://tango.freedesktop.org/static/cvs/tango-art-libre/22x22/tools/draw-text.svg
undo.png
view-refresh.png
wave.png
zoom.png                        http://tango.freedesktop.org/static/cvs/tango-art-libre/22x22/tools/page-magnifier.png
