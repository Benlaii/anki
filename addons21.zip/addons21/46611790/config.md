Updated by [The AnKing](https://www.ankingmed.com) with help from /u/ijgnord. Thanks to [Glutanimate](https://www.glutanimate.com) for the compact mode

<div style="color: #4297F9;"><b>If you enjoy this add-on or want individualized Anki help, please consider supporting us!</b></div>

---

<center><div style="vertical-align:middle;"><a href="https://www.ankingmed.com"><img src="../../addons21/46611790/AnKing/AnKingSmall.png"></a><a href="https://www.ankingmed.com"><img src="../../addons21/46611790/AnKing/TheAnKing.png"></a></div></center>

<center><a href="https://www.facebook.com/ankingmed"><img src="../../addons21/46611790/AnKing/Facebook.jpg"></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="https://www.instagram.com/ankingmed"><img src="../../addons21/46611790/AnKing/Instagram.jpg"></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="https://www.youtube.com/theanking"><img src="../../addons21/46611790/AnKing/YouTube.jpg"></a></center>

<center><a href="https://www.patreon.com/ankingmed"><img src="../../addons21/46611790/AnKing/Patreon.jpg"></a></center>