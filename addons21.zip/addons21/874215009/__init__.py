# -*- coding: utf-8 -*-
# Version: 3.7
# See github page to report issues or to contribute:
# https://github.com/hssm/advanced-browser

from . import advancedbrowser
