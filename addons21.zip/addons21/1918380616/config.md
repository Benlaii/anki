* default search: the value to put by default in the highlight search
* default percent to box: if the percent of tag covered is at least this value, it get boxed
* update default: whether to change this value when you search for something else
* highlight color: color of highlighted background. As in html
* Shortcut of 'number of tags': change the shortcuts of the action, in browser, "number of tags"
* Shortcut of 'and highlight': change the shortcuts of the action, in browser, "and highlight"
